import express from 'express';
import StatusUpdate from '../models/Status.js';
import Team from '../models/Team.js';
import Project from '../models/Project.js';
import User from '../models/User.js';
import Question from '../models/Question.js';
import ExcelJS from 'exceljs';
import { auth, isManager } from '../middleware/auth.js';

const router = express.Router();

router.get('/excel', auth, isManager, async (req, res) => {
  try {
    const { team, teams, user, users, startDate, endDate, month, year } = req.query;

    let teamIds = [];
    let userIds = [];

    if (teams) {
      teamIds = teams.split(',').map(id => id.trim());
    } else if (team) {
      teamIds = [team];
    }

    if (users) {
      userIds = users.split(',').map(id => id.trim());
    } else if (user) {
      userIds = [user];
    }

    let dateFilter = {};
    if (startDate && endDate) {
      dateFilter = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    } else if (month && year) {
      const startMonthDate = new Date(parseInt(year), parseInt(month) - 1, 1);
      const endMonthDate = new Date(parseInt(year), parseInt(month), 0, 23, 59, 59, 999);
      dateFilter = { $gte: startMonthDate, $lte: endMonthDate };
    } else {
      const today = new Date();
      const startMonthDate = new Date(today.getFullYear(), today.getMonth(), 1);
      const endMonthDate = new Date(today.getFullYear(), today.getMonth() + 1, 0, 23, 59, 59, 999);
      dateFilter = { $gte: startMonthDate, $lte: endMonthDate };
    }

    let accessibleTeamIds = [];

    if (req.user.role === 'admin') {
      if (teamIds.length > 0) {
        accessibleTeamIds = teamIds;
      } else {
        const allTeams = await Team.find();
        accessibleTeamIds = allTeams.map(t => t._id.toString());
      }
    } else if (req.user.role === 'manager') {
      const userProjects = req.user.projects || [];
      let queryTeams = [];

      if (teamIds.length > 0) {
        queryTeams = await Team.find({ _id: { $in: teamIds } }).populate('project');
        const authorizedTeams = queryTeams.filter(team =>
          userProjects.some(pid => pid.toString() === team.project._id.toString())
        );

        if (authorizedTeams.length === 0) {
          return res.status(403).json({ message: 'Not authorized to access the requested teams' });
        }

        accessibleTeamIds = authorizedTeams.map(team => team._id.toString());
      } else {
        const teams = await Team.find({ project: { $in: userProjects } });
        accessibleTeamIds = teams.map(team => team._id.toString());
      }
    } else {
      return res.status(403).json({ message: 'Only managers and admins can generate reports' });
    }

    if (accessibleTeamIds.length === 0 && userIds.length === 0) {
      return res.status(404).json({ message: 'No accessible teams or users found' });
    }

    const query = {
      date: dateFilter
    };

    if (userIds.length > 0) {
      query.user = { $in: userIds };
    }

    if (accessibleTeamIds.length > 0) {
      query.team = { $in: accessibleTeamIds };
    }

    const statusUpdates = await StatusUpdate.find(query)
      .sort({ date: 1 })
      .populate('user', 'name')
      .populate('team', 'name')
      .populate('responses.question', 'text isCommon')
      .lean();

    const allDates = [];
    const start = new Date(dateFilter.$gte);
    const end = new Date(dateFilter.$lte);
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      allDates.push(new Date(d));
    }

    const allQuestions = await Question.find({
      $or: [
        { isCommon: true },
        { teams: { $in: accessibleTeamIds } }
      ]
    }).lean();

    const reportTeams = await Team.find({ _id: { $in: accessibleTeamIds } }).lean();
    const reportUsers = await User.find({
      $or: [
        { _id: { $in: userIds } },
        { teams: { $in: accessibleTeamIds } }
      ]
    }).lean();

    const updatesByTeamUserDate = {};
    statusUpdates.forEach(update => {
      const teamId = update.team._id.toString();
      const userId = update.user._id.toString();
      const dateStr = update.date.toISOString().split('T')[0];

      if (!updatesByTeamUserDate[teamId]) updatesByTeamUserDate[teamId] = {};
      if (!updatesByTeamUserDate[teamId][userId]) updatesByTeamUserDate[teamId][userId] = {};
      updatesByTeamUserDate[teamId][userId][dateStr] = update.isLeave
        ? { leaveReason: update.leaveReason || 'Leave' }
        : update.responses;
    });

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Status Report');

    const headers = ['Team', 'User', 'Question'];
    allDates.forEach(date => headers.push(date.toISOString().split('T')[0]));
    worksheet.columns = headers.map((header, i) => ({
      header,
      key: header,
      width: i < 3 ? 20 : 15
    }));

    for (const team of reportTeams) {
      const teamId = team._id.toString();
      const usersInTeam = reportUsers.filter(u => u.teams?.some(tid => tid.toString() === teamId));

      for (const user of usersInTeam) {
        const userId = user._id.toString();
        const questions = allQuestions.filter(q =>
          q.isCommon || q.teams?.some(tid => tid.toString() === teamId)
        );

        questions.forEach((question, qIndex) => {
          const row = {
            Team: qIndex === 0 ? team.name : '',
            User: qIndex === 0 ? user.name : '',
            Question: question.text
          };

          allDates.forEach(date => {
            const dateStr = date.toISOString().split('T')[0];
            const dayData = updatesByTeamUserDate[teamId]?.[userId]?.[dateStr];

            if (dayData?.leaveReason) {
              row[dateStr] = dayData.leaveReason;
            } else {
              const response = Array.isArray(dayData)
                ? dayData.find(r => r.question._id.toString() === question._id.toString())
                : null;
              row[dateStr] = response?.answer || '';
            }
          });

          const addedRow = worksheet.addRow(row);

          // Highlight leave cells
          allDates.forEach(date => {
            const dateStr = date.toISOString().split('T')[0];
            const cell = addedRow.getCell(headers.indexOf(dateStr) + 1);
            const value = (cell.value || '').toString().toLowerCase();

            if (['leave', 'sick leave', 'personal'].includes(value)) {
              cell.fill = {
                type: 'pattern',
                pattern: 'solid',
                fgColor: { argb: 'FFFFA500' }
              };
            }
          });
        });

        worksheet.addRow([]);
      }
    }

    worksheet.getRow(1).font = { bold: true };
    worksheet.getRow(1).alignment = { vertical: 'middle', horizontal: 'center' };

    worksheet.eachRow(row => {
      row.eachCell(cell => {
        cell.border = {
          top: { style: 'thin' },
          left: { style: 'thin' },
          bottom: { style: 'thin' },
          right: { style: 'thin' }
        };
      });
    });

    const buffer = await workbook.xlsx.writeBuffer();
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=status-report.xlsx');
    res.setHeader('Content-Length', buffer.length);
    res.send(buffer);

  } catch (error) {
    console.error('Excel export error:', error);
    res.status(500).json({
      message: 'Server error',
      error: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});


export default router;